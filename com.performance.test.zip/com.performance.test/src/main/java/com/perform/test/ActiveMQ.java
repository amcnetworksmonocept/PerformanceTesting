package com.perform.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnection;// ActiveMQ Server Connection
import org.apache.activemq.ActiveMQConnectionFactory;// Using ActiveMQConnectionFactory Library
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ru.yandex.qatools.allure.annotations.Step;//Allure reports Library 

public class ActiveMQ {
	public static ArrayList<String> reqxml = new ArrayList<String>();

	//====Class Level Variables===
	TextMessage message;
	String data1;
	int filesize;
	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow row = null;
	public XSSFCell cell = null;
	public String[][] excelData = null;
	public int colCount = 0;
	public int rowCount = 0;
	public int lastRow;
	public String[][] excelData2;
	public String path = System.getProperty("user.dir");

	// =========This method works for reading the XML's by it's folder name=======
	public void readxml(String foldername) throws Exception {

		readingExcel("Test");
		int executioncount = 0;
		int count = 1;
		for(int j=1;j<=lastRow;j++) {
			if(foldername.contains(excelData[j][0].toString())) {
				executioncount=Integer.parseInt(excelData[j][1].toString());
				break;
			}
		}

		// ====Read the file name from the folder===		
		String workDir = System.getProperty("user.dir");
		String Path = workDir +"\\Performance\\" +  foldername;		
		File folder = new File(Path);
		//======Take the list of files from the folder====
		File[] listOfFiles = folder.listFiles();

		//File[] listOfFiles = folder.
		String Filename = null;
			for (File file : listOfFiles) {
				if (file.isFile()) {
					//====Read the file name from the folder====
					Filename = file.getName();
					System.out.println("XML Name is : " + Filename);
					logStep("Pushed XML Name on AciveMQ is : " + Filename);
					System.out.println("===================Pushed XML count on ActiveMQ is :---" + count);
					logStep("Pushed XML count on ActiveMQ :" + count);
					@SuppressWarnings("resource")
					BufferedReader r = new BufferedReader(new FileReader(file));
					String line = "";
					//Read XML line by line and append data into reqxml StringBuffer 
					while ((line = r.readLine()) != null) {
						reqxml.add(line.toString());
					}
					//=====Giving the XML's as Input to ActiveMQ Method=====
					activeMQ(reqxml.toString());
				}
				if(executioncount==count) {
					break;
				}
				count = count + 1;
			}
	}

	//======This method works for push XML's to ActiveMQ server=====

	public void activeMQ(String xml) {
		String subject = "AMCN.ESB.ALL.ALL.ALL.XML.QUEUE";
		try {

			// ====Connecting to ActiveMQ server using ActiveMQConnection Factory======
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
					"tcp://dev-adam02.amcnetworks.com:61616/");
			ActiveMQConnection connection = (ActiveMQConnection) connectionFactory.createConnection();

			//====Connection established for ActiveMQ====
			connection.start();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination destination = session.createQueue(subject);

			// =====MessageProducer is used for sending messages to the queue=====
			MessageProducer producer = session.createProducer(destination);

			//====Parsing XML data into ActiveMQ body====
			TextMessage message = session.createTextMessage(xml);

			//======Data send through ActiveMQ====
			producer.send(message);

			System.out.println("JCG printing@@ '" + message.getText() + "'");
			System.out.println("==============================");

			// =======Closes the ActiveMQ connection=====
			connection.close();
			
			

		} catch (Exception e) {
			
            e.printStackTrace();
		}

	}

	// ====This method works for generating the allure reports====
	@Step("{0}")
	public void logStep(String stepName) {
	}

	// ============Method For Reading Excel File and data================
	public String[][] readingexcelFiles(String sheetname) throws Exception {

		try {
			String FilePath = path + "/ExcelFile/API_inputs.xlsx";
			FileInputStream finputStream = new FileInputStream(new File(FilePath));
			workbook = new XSSFWorkbook(finputStream);
			sheet = workbook.getSheet(sheetname);
			colCount = sheet.getRow(0).getPhysicalNumberOfCells();
			// System.out.println("Columns"+ colCount);
			rowCount = sheet.getPhysicalNumberOfRows();
			// System.out.println("Rows"+ rowCount);
			lastRow = sheet.getLastRowNum();
			excelData = new String[rowCount][colCount];
			for (int Nrow = 0; Nrow < rowCount; Nrow++) {
				row = sheet.getRow(Nrow);
				for (int Ncolumn = 0; Ncolumn < colCount; Ncolumn++) {
					cell = sheet.getRow(Nrow).getCell(Ncolumn);
					DataFormatter df = new DataFormatter();
					excelData[Nrow][Ncolumn] = df.formatCellValue(cell);
				}
			}
		} catch (Exception e) {
		}

		return excelData;
	}

	// ========Method For Reading Excel Sheet Based on SheetName=========
	public String readingExcel(String sheetName) {
		logStep("Started reading data from Excel");
		try {
			excelData2 = readingexcelFiles(sheetName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sheetName;
	}


	
	

}
