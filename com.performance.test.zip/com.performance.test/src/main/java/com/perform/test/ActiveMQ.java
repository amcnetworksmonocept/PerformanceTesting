package com.perform.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.advisory.DestinationSource;
import org.apache.activemq.command.ActiveMQQueue;

import com.reusable.test.TestBase;

import ru.yandex.qatools.allure.annotations.Step;

public class ActiveMQ extends TestBase {
	
	public static ArrayList<String> reqxml= new ArrayList<String>();
	TextMessage message;
	String data1;
	int filesize;

	public void readxml(String foldername) throws Exception {
		int count=1;

		//Read the file name from the folder
		String Path = "D:\\AutomationPrerequisites\\Performance\\"+foldername;
		File folder = new File(Path);
		File[] listOfFiles = folder.listFiles();
		String Filename = null;
		for (File file : listOfFiles) {
			if (file.isFile()) {
				Filename = file.getName();
				System.out.println("File Name is : "+Filename);
				
				logStep("XML Name is : "+Filename);
				System.out.println("===================API count is :---"+count);
				
				logStep(" XML count :" + count);
				
				//File file = new File(readExcelValues.data[4][Cap]+Filename);

				BufferedReader r = new BufferedReader(new FileReader(file));

				String line = "";
				String allLine = "";


				while((line=r.readLine()) != null)
				{

					reqxml.add(line.toString());

				}
				activeMQ(reqxml.toString());
			}
			count=count+1;
		}

	}
	public void activeMQ(String xml) {

		String subject = "AMCN.ESB.ALL.ALL.ALL.XML.QUEUE";
		try {
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
					"tcp://dev-adam02.amcnetworks.com:61616/");

			ActiveMQConnection connection = (ActiveMQConnection) connectionFactory.createConnection();
			DestinationSource ds = connection.getDestinationSource();

			connection.start();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination destination = session.createQueue(subject);
			// MessageProducer is used for sending messages to the queue.
			MessageProducer producer = session.createProducer(destination);
			Set<ActiveMQQueue> queues = ds.getQueues();
			//					for (ActiveMQQueue activeMQQueue : queues) {
			//						try {
			//							//System.out.println(activeMQQueue.getQueueName());
			//						} catch (JMSException e) {
			//							e.printStackTrace();
			//						}
			//					}

			TextMessage message = session.createTextMessage(xml);

			producer.send(message);

			//System.out.println("Text updated in :--" + subject + " queue");
			System.out.println("JCG printing@@ '" + message.getText() + "'");
			System.out.println("==============================");
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}


	}
		
	@Step("{0}")
	public void logStep(String stepName) {

	}

}
