package com.perform.test;

import javax.jms.JMSException;

public class UserDefined extends JMSException {

		public UserDefined(String reason) {
		super(reason);
		
	}

		//Overriding toString() method of ArithmeticException as per our needs
	 
	    @Override
	    public String toString()
	    {
	        return "You don't have that much of money in your account";
	    }
	

}
