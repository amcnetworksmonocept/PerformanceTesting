package com.performutility.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnection; // ActiveMQ Server Connection
import org.apache.activemq.ActiveMQConnectionFactory; // Using ActiveMQConnectionFactory Library


public class ActiveMQ extends TestBase {

	// ====Class Level Variables===
	public Session session;
	TextMessage message;
	int filesize;
	public String path = System.getProperty("user.dir");
	public ActiveMQConnection connection;

	// =========This method works for reading the XML's by it's folder name=======

	public void readxml(String foldername) throws Exception {

		// =====Reading the XML count from the XmlDataCountReading sheet=====
		StringBuffer sb = new StringBuffer();
		
		readingExcel("XmlDataCountReading");
		
	     int executioncount = 0;

		int count = 1;

		int excelrowcount = lastRow;

		for (int j = 1; j <= excelrowcount; j++) {
			if (foldername.contains(excelData[j][0].toString())) {
				executioncount = Integer.parseInt(excelData[j][1].toString());
				break;
			}
		}

		// ====Read the file name from the folder===
       if(executioncount>0) {
		String workDir = System.getProperty("user.dir");

		String Path = workDir + "\\Performance\\" + foldername;

		File folder = new File(Path);

		// ======Take the list of files from the folder====
		File[] listOfFiles = folder.listFiles();

		// File[] listOfFiles = folder.
		String Filename = null;

		for (File file : listOfFiles) {

			if (file.isFile()) {

				// ====Read the file name from the folder====
				Filename = file.getName();

				System.out.println("XML Name is : " + Filename);
				logStep("Pushed " + Filename + "on AciveMQ");
				
				logger.info("pushed - " +  Filename  +  "on ActiveMQ");
			
				System.out.println("===================Pushed XML count on ActiveMQ is :---" + count);
				
				logStep("Pushed XML count on ActiveMQ :" + count);
				
				logger.info("Pushed XML count on ActiveMQ :" + count);

				@SuppressWarnings("resource")
				BufferedReader r = new BufferedReader(new FileReader(file));
				String line = "";
				
				// Clearing the StringBuffer
				
				sb.delete(0, sb.length());
				
				// Read XML line by line and append data into reqxml StringBuffer
				
				while ((line = r.readLine()) != null) {
					
					sb.append(line.toString());
					
					System.out.println(line.toString());
				}

				// =====Giving the XML's as Input to ActiveMQ Method=====
				
				activeMQ(sb.toString());
			}
			if (executioncount == count) {
				break;
			}
			count = count + 1;
		}
		
       } else {
    	   
    	   System.out.println("XML Count is " + executioncount);
       }
	}

	// ======ActiveMq Connection Close========

	public void activeMQConnectionClose() throws JMSException {
		
		session.close();
		
		logger.info("Active MQ Connection is Closed");
	}
	

	public void activeMQConnectionStart() throws JMSException {

		try {

			if (!connection.equals("null")) {

				connection.close();

				// ====Connecting to ActiveMQ server using ActiveMQConnection Factory======
				ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
						"tcp://apexqa02-bthpny.amcnetworks.com:61616");
				connection = (ActiveMQConnection) connectionFactory.createConnection();

				// ====Connection established for ActiveMQ====
				connection.start();
				logger.info("Active MQ Connection is Started");
				session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			}
		} catch (Exception e) {
				
			// ====Connecting to ActiveMQ server using ActiveMQConnection Factory======
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
					"tcp://apexqa02-bthpny.amcnetworks.com:61616");
			connection = (ActiveMQConnection) connectionFactory.createConnection();

			// ====Connection established for ActiveMQ====
			connection.start();
			logger.info("Active MQ Connection is Started");
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		}
	}

	public void activeMQ(String xml) {

		String subject = "AMCN.ESB.ALL.ALL.ALL.XML.QUEUE";
		try {

			Destination destination = session.createQueue(subject);

			// =====MessageProducer is used for sending messages to the queue=====
			MessageProducer producer = session.createProducer(destination);

			// ====Parsing XML data into ActiveMQ body====
			TextMessage message = session.createTextMessage(xml);

			// ======Data send through ActiveMQ====
			producer.send(message);
			
			logger.info("XML Data Sending through ActiveMQ");
			
			System.out.println("==============================");

		} catch (Exception e) {

			logStep(e.getMessage());

		}

	}

}
